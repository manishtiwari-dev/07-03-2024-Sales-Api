<?php

namespace Modules\Sales\Models;


use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Str;
use Modules\Sales\Models\Customer;

class InvoiceItemTaxes extends Model
{
    use HasFactory;
    protected $primaryKey = 'id';
    protected $guarded = [
        'id',

    ];
    public function getTable()
    {
        return config('dbtable.acc_invoice_item_taxes');
    }
}
