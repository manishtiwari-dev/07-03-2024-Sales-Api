<?php

namespace Modules\Sales\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Modules\Sales\Models\CustomerContact;
use Modules\Sales\Models\CustomerAddress;
use Modules\CRM\Models\CRMLeadFollowUp;


class Quotation extends Model
{
    use HasFactory;
    protected $primaryKey = 'id';
    protected $guarded = ['id'];

    public function getTable()
    {
        return config('dbtable.crm_quotation');
    }

    public function crm_quotation_to_payment_term()
    {
        return $this->belongsToMany(CRMSettingPaymentTerms::class, config('dbtable.crm_quotation_to_payment_term'), 'id', 'terms_id');
    }

    public function crm_quotation_item()
    {
        return $this->hasMany(QuotationItem::class, 'quotation_id', 'id');
    }

    public function crm_quotation_customer()
    {
        return $this->belongsTo(Customer::class, 'customer_id', 'customer_id');
    }

    public function crm_quotation_contact()
    {
        return $this->belongsTo(CustomerContact::class, 'billing_contact_id', 'contact_id');
    }

    public function crm_quotation_address()
    {
        return $this->belongsTo(CustomerAddress::class, 'billing_address_id', 'address_id');
    }

    public static function quotationCount($id)
    {
        if(!empty($id)){
            $enqcount = Quotation::where('customer_id', $id)->count();
            return $enqcount;
        } else {
            return 0;
        }

    }


    public function followupstatus()
    {
        return $this->hasOne(CRMLeadFollowUp::class, 'source_id', 'id')->where('source', 3);
    }
}
