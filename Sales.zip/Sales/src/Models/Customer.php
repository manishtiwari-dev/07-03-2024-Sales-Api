<?php

namespace Modules\Sales\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Modules\Sales\Models\CustomerAddress;
use Modules\Sales\Models\CustomerContact;
use Modules\CRM\Models\CRMLead;
use Illuminate\Database\Eloquent\Casts\Attribute;
use Modules\Sales\Models\Order;
use Modules\Sales\Models\Enquiry;

class Customer extends Model
{
  use HasFactory;
  protected $primaryKey = 'customer_id';
  protected $guarded = [
    'customer_id',

  ];



  public function getTable()
  {
    return config('dbtable.crm_customer');
  }

  public function lead_data()
  {
    return $this->belongsTo(
      CRMLead::class,
      'lead_id',
      'lead_id'
    );
  }

  public function crm_customer_address()
  {
    return $this->hasMany(CustomerAddress::class, 'customer_id', 'customer_id');
  }
  public function crm_customer_contact()
  {
    return $this->hasMany(CustomerContact::class, 'customer_id', 'customer_id');
  }

  public function weborder()
  {
    return $this->belongsTo(Order::class, 'customer_id', 'customer_id');
  }
  public function webenquiry()
  {
    return $this->belongsTo(Enquiry::class, 'customer_id', 'customer_id');
  }

  public function crmquotation()
  {
    return $this->belongsTo(Quotation::class, 'customer_id', 'customer_id');
  }

  public function webenqcustomer()
  {
    return $this->hasMany(Enquiry::class, 'customer_id', 'customer_id');
  }

  public function webquotecustomer()
  {
    return $this->hasMany(Quotation::class, 'customer_id', 'customer_id');
  }

  public function webordercustomer()
  {
    return $this->hasMany(Order::class, 'customer_id', 'customer_id');
  }

  public function customer_address()
  {
    return $this->hasOne(CustomerAddress::class, 'customer_id', 'customer_id');
  }
}
