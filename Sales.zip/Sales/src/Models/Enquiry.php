<?php

namespace Modules\Sales\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Modules\Sales\Models\EnquiryProducts;
use App\Models\Country;
use Modules\CRM\Models\CRMLeadFollowUp;



class Enquiry extends Model
{
    use HasFactory;

    protected $primaryKey = "enquiry_id";

    public $timestamps = false;

    protected $guarded = [

        'enquiry_id',


    ];


    public function getTable()
    {
        return config('dbtable.web_enquiry');
    }


    public function enquiry_product()
    {
        return $this->hasOne(EnquiryProducts::class, 'enquiry_id', 'enquiry_id');
    }


    public function country_details()
    {
        return $this->belongsTo(Country::class, 'countries_id', 'countries_id');
    }

    public static function enquiryCount($id)
    {
        if(!empty($id)){
            $enqcount = Enquiry::where('customer_id', $id)->count();
            return $enqcount;
        } else{
            return 0;
        }
        

        
    }

    public function followupstatus()
    {
        return $this->hasOne(CRMLeadFollowUp::class, 'source_id', 'enquiry_id')->where('source', 2);
    }
}
