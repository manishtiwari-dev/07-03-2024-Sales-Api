<?php

namespace Modules\Sales\Models;


use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Str;
use Modules\CRM\Models\CRMCustomer;

class Invoices extends Model
{
    use HasFactory;
    protected $primaryKey = 'id';
    protected $guarded = [
        'id',

    ];
    public function getTable()
    {
        return config('dbtable.acc_invoices');
    }

    public function customer()
    {
        return $this->belongsTo(Customer::class, 'customer_id', 'customer_id');
    }

    public function crm_invoice_item()
    {
        return $this->hasMany(InvoicesItem::class, 'invoice_id', 'id');
    }


    public function acc_transaction()
    {
        return $this->hasMany(AccTransactions::class, 'source_id', 'id');
    }
}
