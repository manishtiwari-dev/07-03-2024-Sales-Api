<?php

namespace Modules\CRM\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Validator;
use Modules\CRM\Models\Enquiry;
use Illuminate\Http\Request;
use ApiHelper;
use DateTime;
use App\Jobs\EnquiryUpdateMail;
use Modules\CRM\Models\Super\SuperEnquiry;



class EnquiryController extends Controller
{
    public $page = 'enquiry';
    public $pageview = 'view';
    public $pageadd = 'add';
    public $pagestatus = 'remove';
    public $pageupdate = 'update';

     //super Webenquiry for Super admin

    public function index(Request $request){
       //Validate user page access
        $api_token = $request->api_token;
        if(!ApiHelper::is_page_access($api_token, $this->page, $this->pageview))
             return ApiHelper::JSON_RESPONSE(false,[],'PAGE_ACCESS_DENIED');



        $current_page = !empty($request->page)?$request->page:1;
        $perPage = !empty($request->perPage)?$request->perPage:10;
        $search = $request->search;
        $sortBy = $request->sortBy;
        $orderBy = $request->orderBy;
       // $enquiry_type=$request->enquiry_type;

        /*Fetching subscriber data*/ 

        $enquiry_query = Enquiry::with('enquiry_product','enquiry_product.products.productdescription');
       //   $enquiry_query = ApiHelper::attach_query_permission_filter($enquiry_query, $api_token, $this->page, $this->pageview);

        /*Checking if search data is not empty*/
        if(!empty($search))
            $enquiry_query = $enquiry_query
                ->where("customers_name","LIKE", "%{$search}%")
                ->orWhere("email_address","LIKE", "%{$search}%")
                ->orWhere("company_name", "LIKE", "%{$search}%")
                ->orWhere("enquiry_no","LIKE", "%{$search}%");

        if(empty($request->search)){
            /* Add Start Date Filter  */
                if ($request->has('start_date')) {
                    if($request->start_date !=NULL){
                        $myDateTime = DateTime::createFromFormat('m/d/Y', $request->start_date);
                        $start_date = $myDateTime->format('Y-m-d');
                        
                        $enquiry_query = $enquiry_query->whereDate('created_at', '>=', $start_date);
                  }
                }
    
                /* Add End Date Filter  */
                if ($request->has('end_date')) {
                    if($request->end_date !=NULL){
                        $myDateTime = DateTime::createFromFormat('m/d/Y', $request->end_date);
                        $end_date = $myDateTime->format('Y-m-d');
                        
                        $enquiry_query = $enquiry_query->whereDate('created_at', '<=', $end_date);
                    }
                }
            }

        /* order by sorting */
        if(!empty($sortBy) && !empty($orderBy))
            $enquiry_query = $enquiry_query->orderBy($sortBy,$orderBy);
        else
            $enquiry_query = $enquiry_query->orderBy('enquiry_id','DESC');

        /* Fetching data according enquiry type*/
 
        //if(!empty($enquiry_type))
           //$enquiry_query=$enquiry_query->where('enquiry_type', $enquiry_type);

        $skip = ($current_page == 1)?0:(int)($current_page-1)*$perPage;

        $enquiry_count = $enquiry_query->count();

        $enquiry_list = $enquiry_query->skip($skip)->take($perPage)->get();
        
         /*Binding data into a variable*/
        $res = [
            'enquiry_list'=>$enquiry_list,
            'current_page'=>$current_page,
            'total_records'=>$enquiry_count,
            'total_page'=>ceil((int)$enquiry_count/(int)$perPage),
            'per_page'=>$perPage,
            'start_date'=>$request->start_date,
            'end_date'=>$request->end_date,
        ];
        return ApiHelper::JSON_RESPONSE(true,$res,'');


    }

    public function changeStatus(Request $request)
    {

        $api_token = $request->api_token; 
        $enquiry_id = $request->enquiry_id;
        $sub_data = Enquiry::find($enquiry_id);
        $sub_data->status = $request->status;
        $sub_data->save();
        
        return ApiHelper::JSON_RESPONSE(true,$sub_data,'SUCCESS_STATUS_UPDATE');
    }
    
    public function store(Request $request)
    {
        // Validate user page access
        $api_token = $request->api_token;
        $enquiry_id = $request->enquiry_id;
     
        // $data = Enquiry::UpdateOrCreate(
        //     ['lead_id' => $lead_id],
        //   [
        //       'followup_status' => $request->followup_status,
        //       'next_followup' => $request->next_followup,
              
        //   ]);

          
        //   $business_id = $subscription_data->business_id;
           $enquiry_details = Enquiry::find($enquiry_id);

        $message=$request->message;
          
          if(!empty($message)){
              $details = [
                  'email' => $enquiry_details->email_address,
                  'message'=>  $message
              ];
          }
         
          EnquiryUpdateMail::dispatch($details);

        if ($details) {
            return ApiHelper::JSON_RESPONSE(true, $details, 'SUCCESS_ENQUIRY_ADD');
        } else {
            return ApiHelper::JSON_RESPONSE(false,'', 'ERROR_ENQUIRY_ADD');
        }


    }



    
}
