<?php

namespace Modules\Sales\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use ApiHelper;
use App\Models\Country;
use Modules\CRM\Models\CRMLeadContact;
use Modules\Sales\Models\Customer;
use Modules\Sales\Models\CustomerAddress;
use Modules\Sales\Models\CustomerContact;
use Modules\CRM\Models\CRMLead;
use DateTime;


class SalesCustomerController extends Controller
{

    public $page = 'customer';
    public $pageview = 'view';
    public $pageadd = 'add';
    public $pagestatus = 'remove';
    public $pageupdate = 'update';


    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */


    public function index(Request $request)
    {
        // Validate user page access
        $api_token = $request->api_token;
        if (!ApiHelper::is_page_access($api_token, $this->page, $this->pageview))
            return ApiHelper::JSON_RESPONSE(false, [], 'PAGE_ACCESS_DENIED');

        $current_page = !empty($request->page) ? $request->page : 1;
        $perPage = !empty($request->perPage) ? (int)$request->perPage : ApiHelper::perPageItem();
        $search = $request->search;
        $sortBY = $request->sortBy;
        $ASCTYPE = $request->orderBY;

        $data_query = Customer::with('crm_customer_contact', 'webenqcustomer', 'webquotecustomer', 'webordercustomer');


        if (!empty($search)) {
            $data_query = $data_query->where("company_name", "LIKE", "%{$search}%")
                ->orWhere("first_name", "LIKE", "%{$search}%")->orWhere("email", "LIKE", "%{$search}%");
        }

        if (empty($request->search)) {
            /* Add Start Date Filter  */
            if ($request->has('start_date')) {
                if ($request->start_date != NULL) {
                    $myDateTime = DateTime::createFromFormat('Y-m-d', $request->start_date);
                    $start_date = $myDateTime->format('Y-m-d');
                    $data_query = $data_query->whereDate('created_at', '>=', $start_date);
                }
            }

            /* Add End Date Filter  */
            if ($request->has('end_date')) {
                if ($request->end_date != NULL) {
                    $myDateTime = DateTime::createFromFormat('Y-m-d', $request->end_date);
                    $end_date = $myDateTime->format('Y-m-d');
                    $data_query = $data_query->whereDate('created_at', '<=', $end_date);
                }
            }
        }

        /* order by sorting */
        if (!empty($sortBY) && !empty($ASCTYPE)) {
            $data_query = $data_query->orderBy($sortBY, $ASCTYPE);
        } else {
            $data_query = $data_query->orderBy('customer_id', 'DESC');
        }

        $skip = ($current_page == 1) ? 0 : (int)($current_page - 1) * $perPage;
        $user_count = $data_query->count();

        $data_list = $data_query->skip($skip)->take($perPage)->get();

        $res = [
            'customer_list' => $data_list,
            'current_page' => $current_page,
            'total_records' => $user_count,
            'total_page' => ceil((int)$user_count / (int)$perPage),
            'per_page' => $perPage,
            'start_date' => $request->start_date,
            'end_date' => $request->end_date,
        ];

        return ApiHelper::JSON_RESPONSE(true, $res, '');
    }

    public function create()
    {
        $leaddata = CRMLead::orderBy('lead_id', 'desc')->get();
        $countrydata = Country::all();
        $res = [
            'lead' => $leaddata,
            'country' => $countrydata,
        ];
        return ApiHelper::JSON_RESPONSE(true, $res, '');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */


    public function GenerateAndCheck($model, $column_name, $sizeArray)
    {

        $generatedNumber = ApiHelper::generate_random_token('alphabet', $sizeArray[0]) . ApiHelper::generate_random_token('alpha_numeric', $sizeArray[1]);
        $modelpath = str_replace('"', "", 'Modules\Sales\Models' . '\\' . $model);
        $availabel = $modelpath::where($column_name, $generatedNumber)->first();
        if (!empty($availabel)) {
            $this->GenerateAndCheck($model, $column_name, $sizeArray);
        } else {
            return $generatedNumber;
        }
        // $invoiceId = $this->GenerateAndCheck('Customer', 'invoice_number', [1, 7]);

    }

    public function store(Request $request)
    {
        // Validate user page access
        $api_token = $request->api_token;

        if (!ApiHelper::is_page_access($api_token, $this->page, $this->pageadd))
            return ApiHelper::JSON_RESPONSE(false, [], 'PAGE_ACCESS_DENIED');


        //validation check 
        $validator = Validator::make(
            $request->all(),
            [
                'email' => 'required|email',
                'first_name' => 'required',
            ],

            [
                'email.required' => 'SENDER_NAME_REQUIRED',
                'email.email' => 'ENTER_VALID_EMAIL',
                'first_name.required' => 'ENTER_NAME',
            ]
        );

        if ($validator->fails())
            return ApiHelper::JSON_RESPONSE(false, [], $validator->messages());

        $mailExist = Customer::where('email', $request->email)->first();

        if (!empty($mailExist))
            return ApiHelper::JSON_RESPONSE(false, $request->all(), "E-mail already exist");


        $insert_data = $request->only(['lead_id', 'first_name', 'email', 'date_of_birth', 'contact', 'gender', 'company_name', 'website', 'tax_id']);

        $crmCustomer = Customer::create($insert_data);
        $customer_id = $crmCustomer->customer_id;


        $crmcustomeraddress = CustomerAddress::create([
            'customer_id' => $customer_id,
            'customer_name' => $crmCustomer->first_name,
            'customer_company' => $crmCustomer->company_name,
            'customer_email' => $crmCustomer->email,
            'address_type' => 2,
            'street_address' =>  $request->street_address,
            'city' => $request->city,
            'state' => $request->state,
            'zipcode' => $request->zipcode,
            'countries_id' => $request->countries_id,
            'phone' => $request->phone,
        ]);


        $data = [
            'customerdata' => $crmCustomer,
            'crmcustomeraddress' => $crmcustomeraddress,
            // 'crmcustomercontact' => $crmcustomercontact,
        ];

        if ($data)
            return ApiHelper::JSON_RESPONSE(true, $data, 'SUCCESS_CUSTOMER_ADD');
        else
            return ApiHelper::JSON_RESPONSE(false, '', 'ERROR_CUSTOMER_ADD');
    }
    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit(Request $request)
    {
        $customer = Customer::find($request->id);
        if (!empty($customer)) {
            $customer->crm_customer_address = $customer->crm_customer_address()->select(
                'address_id',
                'address_type',
                'street_address',
                'city',
                'state',
                'zipcode',
                'countries_id',
                'phone',
            )->get();
            $customer->crm_customer_contact = $customer->crm_customer_contact()->select('contact_id', 'contact_name', 'contact_email')->get();
        }


        $lead_list = CRMLead::all();
        $country_list = Country::all();
        $address = CustomerAddress::all();

        $res = [
            'lead_list' => $lead_list,
            'country_list' => $country_list,
            'customer' => $customer,
            'address' => $address,
        ];
        return ApiHelper::JSON_RESPONSE(true, $res, '');
    }


    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request)
    {
        // Validate user page access
        $api_token = $request->api_token;
        if (!ApiHelper::is_page_access($api_token, $this->page, $this->pageupdate))
            return ApiHelper::JSON_RESPONSE(false, [], 'PAGE_ACCESS_DENIED');


        //validation check 
        $validator = Validator::make(
            $request->all(),
            [
                'email' => 'required|email',
                'first_name' => 'required',
            ],
            [
                'email.required' => 'SENDER_NAME_REQUIRED',
                'email.email' => 'ENTER_VALID_EMAIL',
                'first_name.required' => 'ENTER_NAME',
            ]
        );

        if ($validator->fails())
            return ApiHelper::JSON_RESPONSE(false, [], $validator->messages());

        $mailExist = Customer::where('email', $request->email)->where('customer_id', '<>', $request->customer_id)->first();

        if (!empty($mailExist))
            return ApiHelper::JSON_RESPONSE(false, [], "E-mail already exist");


        $customer = Customer::where(['customer_id' => $request->customer_id])->update(
            [
                'lead_id' => $request->lead_id ?? 0,
                'first_name' => $request->first_name,
                'email' => $request->email,
                'date_of_birth' => $request->date_of_birth,
                'contact' => $request->contact,
                'gender' => $request->gender,
                'company_name' => $request->company_name,
                'website' => $request->website,
                'tax_id' => $request->tax_id
            ],

        );


        // CRMCustomerAddress::where('customer_id', $request->customer_id)->delete();

        CustomerAddress::updateOrCreate([
            'customer_id' =>  $request->customer_id,
        ], [
            'customer_name' => $request->first_name,
            'customer_company' => $request->company_name,
            'customer_email' => $request->email,
            'address_type' => 1,
            'street_address' =>  $request->street_address,
            'city' => $request->city,
            'state' => $request->state,
            'zipcode' => $request->zipcode,
            'countries_id' => $request->countries_id,
            'phone' => $request->phone,

        ]);


        if ($customer)
            return ApiHelper::JSON_RESPONSE(true, $customer, 'SUCCESS_CUSTOMER_UPDATE');
        else
            return ApiHelper::JSON_RESPONSE(false, '', 'ERROR_CUSTOMER_UPDATE');
    }

    //view

    public function view(Request $request)
    {
        $response = Customer::find($request->customer_id);
        if (!empty($response)) {
            $response->crm_customer_address = $response->crm_customer_address;
            $response->crm_customer_contact = $response->crm_customer_contact;
        }
        return ApiHelper::JSON_RESPONSE(true, $response, '');
    }


    public function isdefaultupdate(Request $request)
    {
        $upid = $request->update_id;
        $type = $request->type;
        if ($type == 'address') {
            $data = CustomerAddress::find($upid);

            CustomerAddress::where('customer_id', $data->customer_id)->update([
                'is_default' => 0
            ]);

            $data->is_default = 1;
            $data->save();
            return ApiHelper::JSON_RESPONSE(true, ' ', 'ADDRESS-ISDEFAULT_UPDATED');
        } else {
            $contactdata = CustomerContact::find($upid);
            CustomerContact::where('customer_id', $contactdata->customer_id)->update([
                'is_default' => 0,
            ]);
            $contactdata->is_default = 1;
            $contactdata->save();
            return ApiHelper::JSON_RESPONSE(true, '', 'CONTACT-ISDEFAULT_UPDATED');
        }
    }

    public function changeStatus(Request $request)
    {
        $cust =  Customer::where('customer_id', $request->customer_id)->first();
        $cust->status = $cust->status == 1 ? 0 : 1;
        $cust->update();
        return ApiHelper::JSON_RESPONSE(true, $cust, 'SUCCESS_STATUS_UPDATE');
    }

    public function changeGuest(Request $request)
    {
        $cust =  Customer::where('customer_id', $request->customer_id)->first();

        $cust->is_guest = $cust->is_guest == 1 ? 0 : 1;
        $cust->update();
        return ApiHelper::JSON_RESPONSE(true, $cust, 'SUCCESS_STATUS_UPDATE');
    }


    public function customerDetails(Request $request)
    {



        $crmLead = CRMLead::with('crm_lead_contact')->where('lead_id', $request->lead_id)->get();

        return ApiHelper::JSON_RESPONSE(true, $crmLead, 'SUCCESS_STATUS_UPDATE');
    }
}
