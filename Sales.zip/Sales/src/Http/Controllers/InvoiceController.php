<?php

namespace Modules\Sales\Http\Controllers;

use ApiHelper;
use App\Http\Controllers\Controller;
use App\Models\Country;
use App\Models\Currency;
use App\Models\PaymentMethods;
use Carbon\Carbon;
use DateTime;
use Illuminate\Http\Request;
use Modules\CRM\Models\AccAccounts;
use Modules\Account\Models\AccCategories;
use Modules\Sales\Models\Invoices;
use Modules\Sales\Models\InvoicesItem;
use Modules\Sales\Models\Customer;
use Modules\Sales\Models\CustomerAddress;
use Modules\CRM\Models\CRMLead;
use Modules\CRM\Models\CRMServiceItem;
use Modules\SystemSetting\Models\SettingPaymentTerms;
use Modules\SystemSetting\Models\SettingTaxGroup;
use Modules\SystemSetting\Models\SettingTaxPercentage;
use Modules\SystemSetting\Models\SettingTaxType;
use Modules\Sales\Models\QuoteReminderHistory;
use Modules\Sales\Models\Order;
use Modules\Ecommerce\Models\Product;
use Illuminate\Support\Facades\Validator;
use Modules\Account\Models\ACCTransactionHead;

class InvoiceController extends Controller
{

    public $page = 'invoice';
    public $pageview = 'view';
    public $pageadd = 'add';
    public $pagestatus = 'remove';
    public $pageupdate = 'update';

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */

    public function index(Request $request)
    {

        // Validate user page access
        $api_token = $request->api_token;

        if (!ApiHelper::is_page_access($api_token, $this->page, $this->pageview)) {
            return ApiHelper::JSON_RESPONSE(false, [], 'PAGE_ACCESS_DENIED');
        }

        $current_page = !empty($request->page) ? $request->page : 1;
        $perPage =  !empty($request->perPage) ? (int) $request->perPage : ApiHelper::perPageItem();
        $search = $request->search;
        $client = $request->client;
        $status = $request->status;
        $sortBY = $request->sortBy;
        $ASCTYPE = $request->orderBY;

        $invoice_type = ApiHelper::getKeySetVal('invoice_type');

        $source = 1;

        if ($invoice_type == 'products')
            $source = 1;
        else
            $source = 2;

        $data_query = Invoices::with(['customer', 'acc_transaction' => function ($query) {
            $query->where('source', 3);
        }])->orderBy('id', 'desc');

        if (!empty($search)) {
            $data_query = $data_query->where("invoice_number", "LIKE", "%{$search}%");
        }

        if ($request->has('start_date')) {
            if ($request->start_date != null) {
                $myDateTime = DateTime::createFromFormat('Y-m-d', $request->start_date);
                $start_date = $myDateTime->format('Y-m-d');
                $data_query = $data_query->whereDate('created_at', '>=', $start_date);
            }
        }

        /* Add End Date Filter  
        */
        if ($request->has('end_date')) {
            if ($request->end_date != null) {
                $myDateTime = DateTime::createFromFormat('Y-m-d', $request->end_date);
                $end_date = $myDateTime->format('Y-m-d');

                $data_query = $data_query->whereDate('created_at', '<=', $end_date);
            }
        }

        if ($request->has('client')) {
            if ($request->client != null) {
                $data_query = $data_query->where("customer_id", $request->client);
            }
        }

        if ($request->has('status')) {
            if ($request->status != null) {
                $data_query = $data_query->where("status", $request->status);
            }
        }

        if (!empty($sortBY) && !empty($ASCTYPE)) {
            $data_query = $data_query->orderBy($sortBY, $ASCTYPE);
        } else {
            $data_query = $data_query->orderBy('id', 'DESC');
        }

        $data_query = $data_query->where('source', $source);

        $skip = ($current_page == 1) ? 0 : (int) ($current_page - 1) * $perPage;
        $user_count = $data_query->count();

        $data_list = $data_query->skip($skip)->take($perPage)->orderBy('id', 'DESC')->get();
        $dateFormat = ApiHelper::dateFormat();
        $customer = Customer::where('status', 1)->where('is_guest', 0)->get();

        $currency = explode(',', ApiHelper::getKeySetVal('other_supported_currency'));
        $defaultCurrency = ApiHelper::getKeySetVal('default_currency');
        $SelectedTaxGroup = ApiHelper::getKeySetVal('tax_group');
        $crmTaxGroup = SettingTaxGroup::with('tax_info')->where('status', 1)->get();
        $paymentMethodList = PaymentMethods::all();
        $invoices = Invoices::all();
        $orders = Order::all();

        $taxTypeIds = [];

        if (!empty($crmTaxGroup)) {
            foreach ($crmTaxGroup as $taxGroup) {
                if (!empty($taxGroup->tax_info)) {
                    foreach ($taxGroup->tax_info as $taxInfo) {
                        $tax_type = SettingTaxType::where('id', $taxInfo->tax_type_id)->first();
                        $taxInfo->tax_name = $tax_type->tax_name;

                        if (!in_array($taxInfo->tax_type_id, $taxTypeIds)) {
                            $taxTypeIds[] = $taxInfo->tax_type_id;
                        }
                    }
                }
            }
        }

        $accounts = AccAccounts::where('status', 1)->get();
        $crm_income_category = AccCategories::where('status', 1)->where('dr_cr', 'cr')->get();
        $crm_txn_income = ACCTransactionHead::where('status', 1)->where('dr_cr', 'cr')->get();
        $payment_method = PaymentMethods::where('status', 1)->get();

        $res = [
            "app_invoice_list" => $data_list,
            "customer" => $customer,
            'current_page' => $current_page,
            'total_records' => $user_count,
            'total_page' => ceil((int) $user_count / (int) $perPage),
            'per_page' => $perPage,
            'date_format' => $dateFormat,
            'start_date' => $request->start_date,
            'end_date' => $request->end_date,
            "crm_income_category" => $crm_income_category,
            "crm_txn_income" => $crm_txn_income,
            "currency" => $currency,
            "TaxGroup" => $crmTaxGroup,
            'defaultCurrency' => $defaultCurrency,
            'SelectedTaxGroup' => $SelectedTaxGroup,
            'paymentMethodList' => $paymentMethodList,
            'invoices' => $invoices,
            'orders' => $orders,
            "accounts" => $accounts,
            'client' => $client,
            'status' => $status,
            'search' => $search,
            "payment_method" => $payment_method



        ];

        return ApiHelper::JSON_RESPONSE(true, $res, '');
    }

    public function create(Request $request)
    {

        $inv_no_digit = ApiHelper::getKeySetVal('invoice_number_digit');

        // $invoiceId = $this->GenerateAndCheck('Invoices', 'invoice_number', [1, 7]);
        $invoiceId = ApiHelper::generate_invoice_number('alpha_numeric', $inv_no_digit);

        $customer = Customer::where('status', 1)->where('is_guest', 0)->orderBy('customer_id', 'desc')->get();

        $inv_prefix = ApiHelper::getKeySetVal('invoice_prefix');
        $inv_due_after = ApiHelper::getKeySetVal('invoice_due_after');

        foreach ($customer as $Customer) {
            if (!empty($Customer)) {
                $Customer->setRelation('crm_customer_address', $Customer->crm_customer_address()->where(['status' => 1, 'address_type' => 2])->get());
            }

            $address_list = $Customer->crm_customer_address->map(function ($data) {
                if (!empty($data->countries_id)) {
                    $data->country_name = Country::where('countries_id', $data->countries_id)->first()->countries_name;
                } else {
                    $data->country_name = '';
                }

                return $data;
            });
        }

        $currency = explode(',', ApiHelper::getKeySetVal('other_supported_currency'));
        $defaultCurrency = ApiHelper::getKeySetVal('default_currency');

        $paymentterms = SettingPaymentTerms::all();
        $country = Country::all();

        $crmTaxGroup = SettingTaxGroup::with('tax_info')->where('status', 1)->get();

        $taxTypeIds = [];

        if (!empty($crmTaxGroup)) {
            foreach ($crmTaxGroup as $taxGroup) {
                if (!empty($taxGroup->tax_info)) {
                    foreach ($taxGroup->tax_info as $taxInfo) {
                        $tax_type = SettingTaxType::where('id', $taxInfo->tax_type_id)->first();
                        $taxInfo->tax_name = $tax_type->tax_name;

                        if (!in_array($taxInfo->tax_type_id, $taxTypeIds)) {
                            $taxTypeIds[] = $taxInfo->tax_type_id;
                        }
                    }
                }
            }
        }
        $leaddata = CRMLead::orderBy('lead_id', 'desc')->get();
        $countrydata = Country::all();

        $invoice_type = ApiHelper::getKeySetVal('invoice_type');
        $service_items = CRMServiceItem::orderBy('id', 'desc')->get();

        $res = [
            'app_invoice' => $invoiceId,
            'customers' => $customer,
            'currency' => $currency,
            'country' => $country,
            'paymentterms' => $paymentterms,
            'TaxGroup' => $crmTaxGroup,
            'taxTypeIds' => $taxTypeIds,
            'defaultCurrency' => $defaultCurrency,
            'inv_prefix' => $inv_prefix,
            'inv_due_after' => $inv_due_after,
            'invoice_type' => $invoice_type,
            'leaddata' => $leaddata,
            'countrydata' => $countrydata,
            'service_items' => $service_items
        ];

        return ApiHelper::JSON_RESPONSE(true, $res, '');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {

        // Validate user page access
        $api_token = $request->api_token;
        $user_id = ApiHelper::get_user_id_from_token($api_token);

        if (!ApiHelper::is_page_access($api_token, $this->page, $this->pageadd)) {
            return ApiHelper::JSON_RESPONSE(false, [], 'PAGE_ACCESS_DENIED');
        }

        if ($request->item_name == '') {
            return ApiHelper::JSON_RESPONSE(false, [], 'SELECT_ITEM_DETAILS');
        }


        $invNumber = Invoices::where('invoice_number', $request->invoice_number)->first();
        if (!empty($invNumber)) {
            return ApiHelper::JSON_RESPONSE(false, [], 'INVOICE_NUMBER_ALREADY_EXIST');
        }



        $tax_groups = $request->tax_group_id;
        $taxable_amount = $request->item_cost;
        $taxCompo = [];
        foreach ($tax_groups as $key => $value) {

            if (!empty($value)) {
                $taxGroup = SettingTaxGroup::with('tax_info')->where('tax_group_id', $value)->where('status', 1)->first();

                $taxTypeIds = [];

                if (!empty($taxGroup->tax_info)) {
                    foreach ($taxGroup->tax_info as $taxInfo) {
                        $tax_type = SettingTaxType::where('id', $taxInfo->tax_type_id)->first();
                        $taxInfo->tax_name = $tax_type->tax_name;

                        if (!in_array($taxInfo->tax_type_id, $taxTypeIds)) {
                            $taxTypeIds[] = $taxInfo->tax_type_id;
                        }
                    }
                }

                $taxPerVal = $percent = 0;

                foreach ($taxGroup->tax_info as $tax) {

                    // $taxVal = ($taxable_amount[$key] * $tax->tax_percent) / 100;

                    if ($request->tax_type == 1) {
                        $taxVal = ($taxable_amount[$key] * $tax->tax_percent) / 100;
                    } else {
                        $taxVal =  $taxable_amount[$key] * $tax->tax_percent / (100 + $tax->tax_percent);
                    }

                    $taxName = $tax->tax_name;

                    $taxPerVal += $taxVal;
                    // $percent += $tax->tax_percent;

                    $multiArray = array(
                        $taxName => array(
                            "Rate" => $tax->tax_percent,
                            "Value" => number_format($taxVal, 2, '.', ''),
                        ),

                    );

                    array_push($taxCompo, $multiArray);
                }
            }
        }

        $sums = [];

        // Calculate sums for the same SGST and CGST rates
        foreach ($taxCompo as $item) {
            foreach ($item as $key => $value) {
                $rate = $value['Rate'];
                $value = number_format($value['Value']); //floatval($value['Value']);

                if ($key == "SGST" || $key == "CGST" || $key == "IGST") {
                    $newKey = "SGST";
                    if ($key == "CGST") {
                        $newKey = "CGST";
                    }
                    if ($key == "IGST") {
                        $newKey = "IGST";
                    }

                    if (!isset($sums[$newKey])) {
                        $sums[$newKey] = [
                            'Rate' => 0,
                            'Value' => 0,
                        ];
                    }

                    $sums[$newKey]['Rate'] += (float) $rate;
                    $sums[$newKey]['Value'] += (float) $value;
                }
            }
        }

        // Create new array with summed values for SGST and CGST
        $newArray = [
            [
                'SGST' => $sums['SGST'] ?? '',
            ],
            [
                'CGST' => $sums['CGST'] ?? '',
            ],
            [
                'IGST' => $sums['IGST'] ?? '',
            ],
        ];

        $tax_compo = json_encode($newArray);

        $payment_term_id = $request->payment_term_id;
        
        $ad_amount = $bal_amount = 0;
        
        if(isset($payment_term_id)){
            $term_details = SettingPaymentTerms::where('terms_id', $payment_term_id)->first();
            
            if(!empty($term_details)){
    
                $ad_amount = ($request->final_cost * $term_details->advance_payment) / 100;
                $bal_amount = ($request->final_cost * $term_details->balance_payment) / 100;
            }
        }
        
        $data = [
            "Term" => [
                "advance" => [
                    "perc" => $term_details->advance_payment??0,
                    "amount" => $ad_amount
                ],
                "balance" => [
                    "perc" => $term_details->balance_payment??0,
                    "amount" => number_format($bal_amount, 2, '.', ''),
                ],
            ],
        ];

        $payment_term = json_encode($data);



        $invoice = new Invoices();
        $invoice->invoice_number = $request->invoice_number;
        $invoice->customer_id = $request->customer_id;
        $invoice->address_id = $request->billing_address_id;
        $invoice->invoice_title = $request->invoice_title ?? 'Tax_Invoice';
        $invoice->invoice_date = Carbon::createFromFormat('d/m/Y', $request->invoice_date)->format(' Y-m-d');
        $invoice->due_date = Carbon::createFromFormat('d/m/Y', $request->due_date)->format(' Y-m-d');
        $invoice->currency = $request->currency;
        $invoice->subtotal = $request->subtotal;
        $invoice->shipping_cost = $request->shipping_cost;
        $invoice->total_tax = $request->total_tax;
        $invoice->discount = $request->discount;
        $invoice->final_cost = $request->final_cost ?? 0.00;
        $invoice->note = $request->note;
        $invoice->tax_group_id = $request->default_tax_group;
        $invoice->tax_type = $request->tax_type;
        $invoice->payment_term_id = $request->payment_term_id;
        $invoice->status = 'unpaid';
        $invoice->created_by = $user_id;
        $invoice->taxable_value = $request->total_taxable_amount;
        $invoice->details = json_encode($request->details);
        $invoice->tax_component = $tax_compo ?? "";
        $invoice->payment_component = $payment_term ?? "";
        $invoice->source = $request->source;
        $invoice->save();

        if ($invoice) {

            $item_name = $request->item_name;
            $quantity = $request->quantity;
            $unit_price = $request->unit_price;
            $item_discount = $request->item_discount;
            $item_id = $request->item_id;
            $tax_group_id = $request->tax_group_id;
            $item_cost = $request->item_cost;
            $sac_code = $request->sac_code;
            $taxable_amount = $request->taxable_amount;
            $attr = $request->item_attributes;
            $attributeArray = [];

            if (!empty($request->item_attributes)) {
                foreach ($request->item_attributes as $attributes) {
                    $attributeArray[] = $attributes;
                }
            }

            foreach ($item_name as $key => $value) {

                $cal_qty = $quantity[$key] ?? 1;
                $cal_unit_price = $unit_price[$key] ?? 0;
                $cal_discount = $item_discount[$key] ?? 0;
                $tax_percetages = SettingTaxPercentage::where('tax_group_id', $tax_group_id[$key])->sum('tax_percent');
                $tax_amount = ((($cal_qty * $cal_unit_price) - $cal_discount) * $tax_percetages) / 100;

                if (!empty($tax_group_id[$key])) {
                    $taxGroup = SettingTaxGroup::with('tax_info')->where('tax_group_id', $tax_group_id[$key])->where('status', 1)->first();

                    $taxTypeIds = [];

                    if (!empty($taxGroup->tax_info)) {
                        foreach ($taxGroup->tax_info as $taxInfo) {
                            $tax_type = SettingTaxType::where('id', $taxInfo->tax_type_id)->first();
                            $taxInfo->tax_name = $tax_type->tax_name;

                            if (!in_array($taxInfo->tax_type_id, $taxTypeIds)) {
                                $taxTypeIds[] = $taxInfo->tax_type_id;
                            }
                        }
                    }

                    $taxCompo = [];

                    foreach ($taxGroup->tax_info as $tax) {
                        // $taxVal = ($taxable_amount[$key] * $tax->tax_percent) / 100;

                        if ($request->tax_type == 1) {
                            $taxVal = ($item_cost[$key] * $tax->tax_percent) / 100;
                        } else {
                            $taxVal =  $item_cost[$key] * $tax->tax_percent / (100 + $tax->tax_percent);
                        }



                        $taxName = $tax->tax_name;

                        $multiArray = array(
                            $taxName => array(
                                "Rate" => $tax->tax_percent,
                                "Value" =>  number_format($taxVal, 2, '.', ''),
                            ),

                        );

                        array_push($taxCompo, $multiArray);
                    }
                    $tax_component = json_encode($taxCompo);
                }

                // return ApiHelper::JSON_RESPONSE(true, $attr, 'SUCCESS_INVOICE_ADD');

                $acc_invoice_id = InvoicesItem::create([
                    "invoice_id" => $invoice->id,
                    "item_id" => $item_id[$key] ?? 0,
                    "item_name" => $item_name[$key] ?? 0,
                    "sac_code" => $sac_code[$key] ?? '',
                    "quantity" => $quantity[$key] ?? 1,
                    "unit_price" => $unit_price[$key] ?? 0.00,
                    "discount" => $item_discount[$key] ?? 0.00,
                    "item_cost" => $taxable_amount[$key] ?? 0,
                    "attributes" => ($attributeArray[$key] != null) ? json_encode($attributeArray[$key]) : '',
                    "tax_group_id" => $tax_group_id[$key] ?? 0,
                    "tax_amount" => $tax_amount,
                    "final_amount" => $item_cost[$key] ?? 0.00,
                    "tax_component" => $tax_component ?? '',
                    "updated_at" => date("Y-m-d"),
                ]);
            }
        }

        return ApiHelper::JSON_RESPONSE(true, $invoice, 'ADD_SUCCESS');
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit(Request $request)
    {
        // Validate user page access
        $api_token = $request->api_token;

        if (!ApiHelper::is_page_access($api_token, $this->page, $this->pageadd)) {
            return ApiHelper::JSON_RESPONSE(false, [], 'PAGE_ACCESS_DENIED');
        }

        $invoice_type = ApiHelper::getKeySetVal('invoice_type');


        $app_invoice = Invoices::with('crm_invoice_item')->find($request->invoice_id);

        $app_invoice->currency_symbol = Currency::where('currencies_code', $app_invoice->currency)->first()->symbol_left;

        if (!empty($app_invoice)) {
            $data_list = $app_invoice->crm_invoice_item->map(function ($data) use ($request, $invoice_type) {
                $data->tax_group_name = ApiHelper::getGroupName($data->tax_group_id);
                if (!empty($data->item_id) && ($invoice_type == 'products')) {
                    $request->request->add(['product_id' => $data->item_id, 'language' => 1]);
                    $product_data = $this->SearchItemDetail($request)->getData()->data; // Call the function for Product detail with price
                    $data->product_data = $product_data;
                } else {

                    $serviceData = CRMServiceItem::where(['id' => $data->item_id])->first();
                    $data->product_data = $serviceData;
                }
                return $data;
            });
        }

        $app_invo_item = InvoicesItem::where("invoice_id", $app_invoice->id)->first();

        $customer = Customer::where('status', 1)->where('is_guest', 0)->get();

        foreach ($customer as $Customer) {
            if (!empty($Customer)) {
                $Customer->setRelation('crm_customer_address', $Customer->crm_customer_address()->where(['status' => 1, 'address_type' => 2])->get());
            }

            $address_list = $Customer->crm_customer_address->map(function ($data) {
                if (!empty($data->countries_id)) {
                    $data->country_name = Country::where('countries_id', $data->countries_id)->first()->countries_name;
                } else {
                    $data->country_name = '';
                }
                return $data;
            });
        }

        $defaultCurrency = ApiHelper::getKeySetVal('default_currency');
        $currency = explode(',', ApiHelper::getKeySetVal('other_supported_currency'));

        $crmTaxGroup = SettingTaxGroup::with('tax_info')->where('status', 1)->get();

        $taxTypeIds = [];

        if (!empty($crmTaxGroup)) {
            foreach ($crmTaxGroup as $taxGroup) {
                if (!empty($taxGroup->tax_info)) {
                    foreach ($taxGroup->tax_info as $taxInfo) {
                        $tax_type = SettingTaxType::where('id', $taxInfo->tax_type_id)->first();
                        $taxInfo->tax_name = $tax_type->tax_name;

                        if (!in_array($taxInfo->tax_type_id, $taxTypeIds)) {
                            $taxTypeIds[] = $taxInfo->tax_type_id;
                        }
                    }
                }
            }
        }

        $invoice_data = [];

        $invoice_data['invoice_logo'] = ApiHelper::getKeySetVal('invoice_logo');
        $invoice_data['invoice_note'] = ApiHelper::getKeySetVal('invoice_note');
        $invoice_data['invoice_prefix'] = ApiHelper::getKeySetVal('invoice_prefix');

        $invoice_data['invoice_biller_address'] = !empty(ApiHelper::getKeySetVal('invoice_biller_address')) ? ApiHelper::getKeySetVal('invoice_biller_address') : ApiHelper::getKeyVal('contact_address')
            . ' ,' . ApiHelper::getKeyVal('contact_city') . ' ,' . ApiHelper::getKeyVal('contact_state') . ' ,' . ApiHelper::getKeyVal('contact_country') . ' ,' . ApiHelper::getKeyVal('contact_zipcode');
        $invoice_data['business_email'] = ApiHelper::getKeySetVal('business_email');
        $invoice_data['contact_phone'] = ApiHelper::getKeyVal('contact_phone');
        $invoice_data['company_name'] = !empty(ApiHelper::getKeySetVal('business_name')) ? ApiHelper::getKeySetVal('business_name') : ApiHelper::getKeyVal('company_name');

        $customer_addrs = CustomerAddress::where('address_id', $app_invoice->billing_address_id)->first();
        if (!empty($customer_addrs)) {

            if (!empty($customer_addrs->countries_id)) {
                $customer_addrs['country_name'] = Country::where('countries_id', $customer_addrs->countries_id)->first()->countries_name;
            } else {
                $customer_addrs['country_name'] = '';
            }
        }

        $invoice_data['customer_address'] = $customer_addrs;

        $paymentterms = SettingPaymentTerms::all();
        $service_items = CRMServiceItem::orderBy('id', 'desc')->get();




        $res = [
            'app_invoice' => $app_invoice,
            'app_invo_item' => $app_invo_item,
            'customer' => $customer,
            'currency' => $currency,
            'TaxGroup' => $crmTaxGroup,
            'taxTypeIds' => $taxTypeIds,
            'defaultCurrency' => $defaultCurrency,
            'paymentterms' => $paymentterms,
            'invoice_data' => $invoice_data,
            'website_url' => ApiHelper::getKeyVal('website_url'),
            'invoice_type' => $invoice_type,
            'service_items' => $service_items
        ];

        return ApiHelper::JSON_RESPONSE(true, $res, '');
    }
    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request)
    {
        // Validate user page access
        $api_token = $request->api_token;

        if (!ApiHelper::is_page_access($api_token, $this->page, $this->pageadd)) {
            return ApiHelper::JSON_RESPONSE(false, [], 'PAGE_ACCESS_DENIED');
        }

        if ($request->item_name == '') {
            return ApiHelper::JSON_RESPONSE(false, [], 'SELECT_ITEM_DETAILS');
        }

        $tax_groups = $request->tax_group_id;
        $taxable_amount = $request->taxable_amount;
        $taxCompo = [];
        foreach ($tax_groups as $key => $value) {

            if (!empty($value)) {
                $taxGroup = SettingTaxGroup::with('tax_info')->where('tax_group_id', $value)->where('status', 1)->first();

                $taxTypeIds = [];

                if (!empty($taxGroup->tax_info)) {
                    foreach ($taxGroup->tax_info as $taxInfo) {
                        $tax_type = SettingTaxType::where('id', $taxInfo->tax_type_id)->first();
                        $taxInfo->tax_name = $tax_type->tax_name;

                        if (!in_array($taxInfo->tax_type_id, $taxTypeIds)) {
                            $taxTypeIds[] = $taxInfo->tax_type_id;
                        }
                    }
                }

                $taxPerVal = $percent = 0;

                foreach ($taxGroup->tax_info as $tax) {
                    $taxVal = ($taxable_amount[$key] * $tax->tax_percent) / 100;

                    $taxName = $tax->tax_name;

                    $taxPerVal += $taxVal;
                    // $percent += $tax->tax_percent;

                    $multiArray = array(
                        $taxName => array(
                            "Rate" => $tax->tax_percent,
                            "Value" => number_format($taxVal, 2, '.', ''),
                        ),

                    );

                    array_push($taxCompo, $multiArray);
                }
            }
        }

        $sums = [];

        // Calculate sums for the same SGST and CGST rates
        foreach ($taxCompo as $item) {
            foreach ($item as $key => $value) {
                $rate = $value['Rate'];
                $value = number_format($value['Value']); //floatval($value['Value']);

                if ($key == "SGST" || $key == "CGST" || $key == "IGST") {
                    $newKey = "SGST";
                    if ($key == "CGST") {
                        $newKey = "CGST";
                    }
                    if ($key == "IGST") {
                        $newKey = "IGST";
                    }

                    if (!isset($sums[$newKey])) {
                        $sums[$newKey] = [
                            'Rate' => 0,
                            'Value' => 0,
                        ];
                    }

                    $sums[$newKey]['Rate'] += (float) $rate;
                    $sums[$newKey]['Value'] += (float) $value;
                }
            }
        }
        // return ApiHelper::JSON_RESPONSE(false, $sums, 'PAGE_ACCESS_DENIED');

        // Create new array with summed values for SGST and CGST
        $newArray = [
            [
                'SGST' => $sums['SGST'] ?? '',
            ],
            [
                'CGST' => $sums['CGST'] ?? '',
            ],
            [
                'IGST' => $sums['IGST'] ?? '',
            ],
        ];

        $tax_compo = json_encode($newArray);

        $payment_term_id = $request->payment_term_id;
        
        $ad_amount = $bal_amount = 0;
        
        if(isset($payment_term_id)){
            $term_details = SettingPaymentTerms::where('terms_id', $payment_term_id)->first();
            
            if(!empty($term_details)){
    
                $ad_amount = ($request->final_cost * $term_details->advance_payment) / 100;
                $bal_amount = ($request->final_cost * $term_details->balance_payment) / 100;
            }
        }
        $data = [
            "Term" => [
                "advance" => [
                    "perc" => $term_details->advance_payment??0,
                    "amount" => $ad_amount
                ],
                "balance" => [
                    "perc" => $term_details->balance_payment??0,
                    "amount" => number_format($bal_amount, 2, '.', ''),
                ],
            ],
        ];

        $payment_term = json_encode($data);

        try {
            $invoice = Invoices::find($request->invoice_id);
            $invoice->invoice_number = $request->invoice_number;
            $invoice->customer_id = $request->customer_id;
            $invoice->address_id = $request->billing_address_id;
            $invoice->invoice_title = $request->invoice_title ?? 'Tax_Invoice';
            $invoice->invoice_date = Carbon::createFromFormat('d/m/Y', $request->invoice_date)->format(' Y-m-d');
            $invoice->due_date = Carbon::createFromFormat('d/m/Y', $request->due_date)->format(' Y-m-d');
            $invoice->currency = $request->currency;
            $invoice->subtotal = $request->subtotal;
            $invoice->shipping_cost = $request->shipping_cost;
            $invoice->total_tax = $request->total_tax;
            $invoice->discount = $request->discount;
            $invoice->final_cost = $request->final_cost;
            $invoice->tax_group_id = $request->default_tax_group;
            $invoice->tax_type = $request->tax_type;
            $invoice->note = $request->note;
            $invoice->payment_term_id = $request->payment_term_id;
            $invoice->taxable_value = $request->total_taxable_amount;
            $invoice->status = 'unpaid';
            $invoice->details = json_encode($request->details);
            $invoice->tax_component = $tax_compo ?? '';
            $invoice->payment_component = $payment_term ?? '';
            $invoice->source = $request->source;
            $invoice->update();

            if ($invoice) {

                $item_name = $request->item_name;
                $quantity = $request->quantity;
                $unit_price = $request->unit_price;
                $item_discount = $request->item_discount;
                $item_id = $request->item_id;
                $invoice_item_id = $request->invoice_item_id;
                $tax_group_id = $request->tax_group_id;
                $item_cost = $request->item_cost;
                $sac_code = $request->sac_code;
                $taxable_amount = $request->taxable_amount;
                $attributeArray = [];

                if (!empty($request->item_attributes)) {
                    foreach ($request->item_attributes as $attributes) {
                        $attributeArray[] = $attributes;
                    }
                }

                $invoiceItmAry = [];
                $invoiceItmAry = InvoicesItem::where('invoice_id', $invoice->id)->pluck('id')->all();

                // InvoicesItem::where('invoice_id', $request->invoice_id)->delete();

                if ($item_name) {
                    foreach ($item_name as $key => $value) {

                        $cal_qty = $quantity[$key] ?? 1;
                        $cal_unit_price = $unit_price[$key] ?? 0;
                        $cal_discount = $item_discount[$key] ?? 0;
                        $tax_percetages = SettingTaxPercentage::where('tax_group_id', $tax_group_id[$key])->sum('tax_percent');
                        $tax_amount = ((($cal_qty * $cal_unit_price) - $cal_discount) * $tax_percetages) / 100;

                        $taxGroup = SettingTaxGroup::with('tax_info')->where('tax_group_id', $tax_group_id[$key] ?? 0)->where('status', 1)->first();

                        $taxTypeIds = [];

                        $tax_component = '';

                        if (isset($tax_group_id[$key]) && !is_null($tax_group_id[$key])) {

                            $taxGroup = SettingTaxGroup::with('tax_info')->where('tax_group_id', $tax_group_id[$key])->where('status', 1)->first();

                            $taxTypeIds = [];

                            if (!empty($taxGroup->tax_info)) {
                                foreach ($taxGroup->tax_info as $taxInfo) {
                                    $tax_type = SettingTaxType::where('id', $taxInfo->tax_type_id)->first();
                                    $taxInfo->tax_name = $tax_type->tax_name;

                                    if (!in_array($taxInfo->tax_type_id, $taxTypeIds)) {
                                        $taxTypeIds[] = $taxInfo->tax_type_id;
                                    }
                                }
                            }

                            $taxCompo = [];

                            foreach ($taxGroup->tax_info as $tax) {
                                $taxVal = ($taxable_amount[$key] * $tax->tax_percent) / 100;

                                $taxName = $tax->tax_name;

                                $multiArray = array(
                                    $taxName => array(
                                        "Rate" => $tax->tax_percent,
                                        "Value" =>  number_format($taxVal, 2, '.', ''),
                                    ),

                                );

                                array_push($taxCompo, $multiArray);
                            }
                            $tax_component = json_encode($taxCompo);
                        }

                        if (isset($invoice_item_id[$key]) && $invoice_item_id[$key] > 0) {

                            $curInvoiceItemAry[] = $invoice_item_id[$key];

                            $accInvoiceDetails = InvoicesItem::where('id', $invoice_item_id[$key])->first();

                            if (!empty($accInvoiceDetails)) {

                                $accInvoiceDetails->invoice_id = $invoice->id;
                                $accInvoiceDetails->item_name = $item_name[$key] ?? 0;
                                $accInvoiceDetails->sac_code = $sac_code[$key] ?? '';
                                $accInvoiceDetails->quantity = $quantity[$key] ?? 1;
                                $accInvoiceDetails->unit_price = $unit_price[$key] ?? 0;
                                $accInvoiceDetails->discount = $item_discount[$key] ?? 0;
                                $accInvoiceDetails->item_cost = $taxable_amount[$key] ?? 0;
                                $accInvoiceDetails->attributes = sizeof($attributeArray) > 0 ? json_encode($attributeArray[$key]) : '';
                                $accInvoiceDetails->tax_group_id = $tax_group_id[$key] ?? 0;
                                $accInvoiceDetails->tax_amount = $tax_amount;
                                $accInvoiceDetails->final_amount = $item_cost[$key] ?? 0.00;
                                $accInvoiceDetails->tax_component = $tax_component ?? '';
                                $accInvoiceDetails->updated_at = date("Y-m-d");
                                $accInvoiceDetails->update();
                            }
                        } else {

                            InvoicesItem::create([
                                "invoice_id" => $invoice->id,
                                "item_id" => $item_id[$key] ?? 0,
                                "item_name" => $item_name[$key] ?? 0,
                                "sac_code" => $sac_code[$key] ?? '',
                                "quantity" => $quantity[$key] ?? 1,
                                "unit_price" => $unit_price[$key] ?? 0,
                                "discount" => $item_discount[$key] ?? 0,
                                "item_cost" => $taxable_amount[$key] ?? 0,
                                "attributes" => sizeof($attributeArray) > 0 ? json_encode($attributeArray[$key]) : '',
                                "tax_group_id" => $tax_group_id[$key] ?? 0,
                                "tax_amount" => $tax_amount,
                                "final_amount" => $item_cost[$key] ?? 0.00,
                                "tax_component" => $tax_component ?? ''
                            ]);
                        }
                    } // end foreach


                    //Delete elements which are remove from item list in invoice.

                    $firstArrayIds = array_map('intval', $curInvoiceItemAry); // [1, 8]
                    $secondArrayIds = array_map('intval', $invoiceItmAry); // [1, 8, 9]

                    $idsToDeletes = array_diff($secondArrayIds, $firstArrayIds);
                    if (!empty($idsToDeletes)) {
                        foreach ($idsToDeletes as $deletId) {
                            InvoicesItem::where('id', $deletId)->delete();
                        }
                    }
                }
            }

            return ApiHelper::JSON_RESPONSE(true, $idsToDeletes, 'UPDATE_SUCCESS');
        } catch (Exception $e) {
            return ApiHelper::JSON_RESPONSE(false, $e->getMessage(), 'ERROR_INVOICE_UPDATE');
        }
    }

    public function destroy(Request $request)
    {
        CRMExpenses::where('id', $request->id)->delete();

        return ApiHelper::JSON_RESPONSE(true, [], 'DELETE_SUCCESS');
    }

    public function GenerateAndCheck($model, $column_name, $sizeArray)
    {

        $inv_no_digit = ApiHelper::getKeySetVal('invoice_number_digit');

        $generatedNumber = ApiHelper::generate_random_token('alphabet', $sizeArray[0]) . ApiHelper::generate_random_token('alpha_numeric', $sizeArray[1]);
        $modelpath = str_replace('"', "", 'Modules\Sales\Models' . '\\' . $model);
        $availabel = $modelpath::where($column_name, $generatedNumber)->first();
        if (!empty($availabel)) {
            $this->GenerateAndCheck($model, $column_name, $sizeArray);
        } else {
            return $generatedNumber;
        }
    }

    public function SearchItemDetail(Request $request)
    {
        $language = $request->language;
        $product_id = $request->product_id;

        $product = Product::with('productdescription', 'productAttribute')->where('product_id', $product_id)->first();

        if (!empty($product)) {

            $pr = $product->productdescription()->where('languages_id', $language)->first();
            $product->products_name = ($pr == null) ? '' : $pr->products_name;
            $product->products_description = ($pr == null) ? '' : $pr->products_description;

            // relate with attach attributes
            $attributes = $product->productAttribute()->with('productOptions')->groupBy('options_id')->get();

            if (!empty($attributes)) {
                $attributes->map(function ($option) use ($product) {
                    $option->option_name = $option->productOptions->products_options_name;
                    $option->option_value_list = $product->productAttribute()->with('productOptionsValue')->where('options_id', $option->options_id)->get();
                    return $option;
                });
            }
            $product->productAttribute = $attributes;

            $product->attribute_sale_price = null;

            $resArray = Product::GetSalePrice($product->product_id);

            $product->sale_price = $resArray['sale_price'];
            $product->bulkPrice = $resArray['bulkPrice'];

            $product_qty = $resArray['qty'] ?? 1;

            $attribute_array = [];

            $itemAttribute = $product->productAttribute()->with('productOptions')->get();

            if (!empty($itemAttribute)) {
                foreach ($itemAttribute as $key => $attribute) {
                    $attribute_array[$key]['options_id'] = $attribute->options_id;
                    $attribute_array[$key]['options_values_id'] = $attribute->options_values_id;
                }

                $request['attribute_array'] = $attribute_array;
                $request['OrderdQty'] = 1;

                // $product->attribute_sale_price = $this->attributeToprice($request)->getData()->final_price;
                // $product->discount = $this->attributeToprice($request)->getData()->totalDiscountPrice;

                $product->product_qty = $product_qty;
            }

            return ApiHelper::JSON_RESPONSE(true, $product, 'SUCCESS');
        } else {
            return ApiHelper::JSON_RESPONSE(true, [], 'ERROR');
        }
    }

    public function SearchServiceDetail(Request $request)
    {
    }

    public function mailSenderHelper($Quote_data)
    {
        $customer_data = Customer::find($Quote_data->customer_id);

        $dt = Carbon::now();
        $today_date = $dt->toDateString();

        $mail_data = [
            'sender_name' => 'Sender Name',
            'sender_email' => 'senderemail@gmail.com',
            'subject' => "Quotation Reminder",
            'content' => "Please Pay your payment",
            // 'unsubscription_url' => url()->full(),
            'customer_data' => $customer_data,
            'web_base_url' => ApiHelper::getKeyVal('website_url'),
        ];

        try {
            QuoteReminderHistory::create([
                'quote_id' => $Quote_data->quotation_id,
                'sent_at' => $today_date,
            ]);
            QuoteReminderJob::dispatch($mail_data)->delay(now()->addSeconds(value: 5));
        } catch (Exception $e) {
            echo ($e->getMessage());
        }
    }

    public function InvoiceDetailsPDF(Request $request)
    {
        $api_token = $request->api_token;

        $response = Invoices::with('crm_invoice_item', 'customer')->where('invoice_number', $request->invoice_no)->first();
        $response->currency_symbol = Currency::where('currencies_code', $response->currency)->first()->symbol_left;
        if (!empty($response->crm_quotation_address)) {

            // $response->crm_quotation_address->country_name = Country::where('countries_id', $response->crm_quotation_address->countries_id)->first()->countries_name;

            if (!empty($response->crm_quotation_address->countries_id)) {
                $response->crm_quotation_address->country_name = Country::where('countries_id', $response->crm_quotation_address->countries_id)->first()->countries_name;
            } else {
                $response->crm_quotation_address->country_name  = '';
            }
        }

        $invoice_type = ApiHelper::getKeySetVal('invoice_type');


        if (!empty($response)) {
            $data_list = $response->crm_invoice_item->map(function ($data) use ($request, $invoice_type) {
                $data->tax_group_name = ApiHelper::getGroupName($data->tax_group_id);

                if (!empty($data->item_id) && ($invoice_type == 'products')) {
                    $request->request->add(['product_id' => $data->item_id, 'language' => 1]);
                    $product_data = $this->SearchItemDetail($request)->getData()->data; // Call the function for Product detail with price
                    $data->product_data = $product_data;
                } else {

                    $serviceData = CRMServiceItem::where(['id' => $data->item_id])->first();
                    $data->product_data = $serviceData;
                }

                return $data;
            });
        }

        // Invoice Sender Data Work Here

        $invoice_data = [];

        $invoice_data['invoice_logo'] = ApiHelper::getFullImageUrl(ApiHelper::getKeySetVal('invoice_logo'));
        $invoice_data['invoice_note'] = ApiHelper::getKeySetVal('invoice_note');
        $invoice_data['invoice_prefix'] = ApiHelper::getKeySetVal('invoice_prefix');
        $invoice_data['term_condition'] = ApiHelper::getKeySetVal('invoice_term_and_condition');
        $invoice_data['invoice_note'] = ApiHelper::getKeySetVal('invoice_note');
        $invoice_data['bank_account'] = ApiHelper::getKeySetVal('invoice_bank_account');

        $invoice_data['invoice_biller_address'] = !empty(ApiHelper::getKeySetVal('invoice_biller_address')) ? ApiHelper::getKeySetVal('invoice_biller_address') : ApiHelper::getKeyVal('contact_address')
            . ' ,' . ApiHelper::getKeyVal('contact_city') . ' ,' . ApiHelper::getKeyVal('contact_state') . ' ,' . ApiHelper::getKeyVal('contact_country') . ' ,' . ApiHelper::getKeyVal('contact_zipcode');
        $invoice_data['business_email'] = ApiHelper::getKeySetVal('business_email');
        $invoice_data['contact_phone'] = ApiHelper::getKeyVal('contact_phone');
        $invoice_data['company_name'] = !empty(ApiHelper::getKeySetVal('business_name')) ? ApiHelper::getKeySetVal('business_name') : ApiHelper::getKeyVal('company_name');


        $res = [
            'quote_detail' => $response,
            'invoice_data' => $invoice_data,
            'invoice_type' => $invoice_type,
        ];

        return ApiHelper::JSON_RESPONSE(true, $res, '');
    }

    public function changeStatus(Request $request)
    {
        $invoiceId = $request->invoiceId;
        $statusId = $request->statusId;

        if (empty($statusId) || empty($invoiceId)) {
            return ApiHelper::JSON_RESPONSE(false, '', 'SOME_FIELD_MISSING');
        }

        $quote = Invoices::find($invoiceId);
        $quote->status = $statusId;
        $quote->save();

        if ($quote) {
            return ApiHelper::JSON_RESPONSE(true, $quote, 'SUCCESS_STATUS_UPDATE');
        } else {
            return ApiHelper::JSON_RESPONSE(false, '', 'ERROR_STATUS_UPDATE');
        }
    }

    public function changeDate(Request $request)
    {

        $inv_due_after = ApiHelper::getKeySetVal('invoice_due_after');

        $date = Carbon::createFromFormat('d/m/Y', $request->invoice_date)->addDays($inv_due_after)->format('d/m/Y');

        return ApiHelper::JSON_RESPONSE(true, $date, 'SUCCESS_STATUS_UPDATE');
    }

    public function serviceAdd(Request $request)
    {

        $service = new CRMServiceItem();
        $service->item_name = $request->service_name;
        $service->item_saccode = $request->item_saccode;
        $service->item_price = $request->item_price;
        $service->tax_group_id = $request->tax_group;
        $service->save();

        if ($service) {
            return ApiHelper::JSON_RESPONSE(true, $service, 'UPDATE_SUCCESS');
        } else {
            return ApiHelper::JSON_RESPONSE(false, '', 'ERROR_SERVICE ADD');
        }
    }

    public function invoiceDownload(Request $request)
    {

        $api_token = $request->api_token;

        $response = Invoices::with('crm_invoice_item', 'customer')->where('invoice_number', $request->invoice_no)->first();

        $response->currency_symbol = Currency::where('currencies_code', $response->currency)->first()->symbol_left;

        if (!empty($response->crm_quotation_address)) {
            // $response->crm_quotation_address->country_name = Country::where('countries_id', $response->crm_quotation_address->countries_id)->first()->countries_name;

            if (!empty($response->crm_quotation_address->countries_id)) {
                $response->crm_quotation_address->country_name = Country::where('countries_id', $response->crm_quotation_address->countries_id)->first()->countries_name;
            } else {
                $response->crm_quotation_address->country_name  = '';
            }
        }

        $invoice_type = ApiHelper::getKeySetVal('invoice_type');

        if (!empty($response)) {
            $data_list = $response->crm_invoice_item->map(function ($data) use ($request, $invoice_type) {
                $data->tax_group_name = ApiHelper::getGroupName($data->tax_group_id);

                if (!empty($data->item_id) && ($invoice_type == 'products')) {
                    $request->request->add(['product_id' => $data->item_id, 'language' => 1]);
                    $product_data = $this->SearchItemDetail($request)->getData()->data; // Call the function for Product detail with price
                    $data->product_data = $product_data;
                } else {

                    $serviceData = CRMServiceItem::where(['id' => $data->item_id])->first();
                    $data->product_data = $serviceData;
                }

                return $data;
            });
        }

        // Invoice Sender Data Work Here

        $invoice_data = [];

        $invoice_data['invoice_logo'] = ApiHelper::getFullImageUrl(ApiHelper::getKeySetVal('invoice_logo'));
        $invoice_data['invoice_note'] = ApiHelper::getKeySetVal('invoice_note');
        $invoice_data['invoice_prefix'] = ApiHelper::getKeySetVal('invoice_prefix');
        $invoice_data['term_condition'] = ApiHelper::getKeySetVal('invoice_term_and_condition');
        $invoice_data['invoice_declaration'] = ApiHelper::getKeySetVal('invoice_declaration');
        $invoice_data['invoice_footer_info'] = ApiHelper::getKeySetVal('invoice_footer_info');
        $invoice_data['invoice_note'] = ApiHelper::getKeySetVal('invoice_note');
        $invoice_data['bank_account'] = ApiHelper::getKeySetVal('invoice_bank_account');

        $invoice_data['invoice_biller_address'] = !empty(ApiHelper::getKeySetVal('invoice_biller_address')) ? ApiHelper::getKeySetVal('invoice_biller_address') : ApiHelper::getKeyVal('contact_address')
            . ' ,' . ApiHelper::getKeyVal('contact_city') . ' ,' . ApiHelper::getKeyVal('contact_state') . ' ,' . ApiHelper::getKeyVal('contact_country') . ' ,' . ApiHelper::getKeyVal('contact_zipcode');
        $invoice_data['business_email'] = ApiHelper::getKeySetVal('business_email');
        $invoice_data['contact_phone'] = ApiHelper::getKeyVal('contact_phone');
        $invoice_data['company_name'] = !empty(ApiHelper::getKeySetVal('business_name')) ? ApiHelper::getKeySetVal('business_name') : ApiHelper::getKeyVal('company_name');

        $invoice_type = ApiHelper::getKeySetVal('invoice_type');
        $crmTaxGroup = SettingTaxGroup::with('tax_info')->where('status', 1)->get();
        $taxTypeIds = [];

        if (!empty($crmTaxGroup)) {
            foreach ($crmTaxGroup as $taxGroup) {
                if (!empty($taxGroup->tax_info)) {
                    foreach ($taxGroup->tax_info as $taxInfo) {
                        $tax_type = SettingTaxType::where('id', $taxInfo->tax_type_id)->first();
                        $taxInfo->tax_name = $tax_type->tax_name;

                        if (!in_array($taxInfo->tax_type_id, $taxTypeIds)) {
                            $taxTypeIds[] = $taxInfo->tax_type_id;
                        }
                    }
                }
            }
        }

        // foreach($responseData->data->quote_detail->crm_invoice_item as $productItem){
        $response->crm_invoice_item->map(function ($data) use ($crmTaxGroup) {

            $taxInfo = $this->getTaxInfoByTaxGroupId($crmTaxGroup, $data->tax_group_id);

            if ($taxInfo !== null) {
                foreach ($taxInfo as $tax_details) {
                    $tax[$tax_details->tax_name] = [
                        'tax_percentage' => $tax_details->tax_percent,
                        'tax_amount' => ($data->item_cost * $tax_details->tax_percent) / 100,
                    ];
                }

                $data->tax = $tax;

                return $data;
            } else {
            }
        });
        //   }

        $Customer = CustomerAddress::where('customer_id', $response->customer->customer_id)->where('status', 1)->get();

        $address_list = $Customer->map(function ($data) {
            // $data->country_name = Country::where('countries_id', $data->countries_id)->first()->countries_name;

            if (!empty($data->countries_id)) {
                $data->country_name = Country::where('countries_id', $data->countries_id)->first()->countries_name;
            } else {
                $data->country_name  = '';
            }


            return $data;
        });

        $currencyName = ApiHelper::getCurrencyName($response->currency);

        $res = [
            'quote_detail' => $response,
            'invoice_data' => $invoice_data,
            'invoice_type' => $invoice_type,
            'crmTaxGroup' => $crmTaxGroup,
            'address_list' => $address_list,
            'currencyName' => $currencyName,
        ];

        return ApiHelper::JSON_RESPONSE(true, $res, '');
    }

    public function getTaxInfoByTaxGroupId($taxGroupArray, $targetTaxGroupId)
    {
        foreach ($taxGroupArray as $taxGroup) {
            if ($taxGroup->tax_group_id === $targetTaxGroupId) {
                return $taxGroup->tax_info;
            }
        }
        return null; // Return null if tax_group_id is not found
    }

    public function dublicate(Request $request)
    {
        // Validate user page access
        $api_token = $request->api_token;

        if (!ApiHelper::is_page_access($api_token, $this->page, $this->pageadd)) {
            return ApiHelper::JSON_RESPONSE(false, [], 'PAGE_ACCESS_DENIED');
        }

        $invoice_type = ApiHelper::getKeySetVal('invoice_type');
        $app_invoice = Invoices::with('crm_invoice_item')->find($request->invoice_id);

        $app_invoice->currency_symbol = Currency::where('currencies_code', $app_invoice->currency)->first()->symbol_left;

        if (!empty($app_invoice)) {
            $data_list = $app_invoice->crm_invoice_item->map(function ($data) use ($request, $invoice_type) {
                $data->tax_group_name = ApiHelper::getGroupName($data->tax_group_id);
                if (!empty($data->item_id) && ($invoice_type == 'products')) {
                    $request->request->add(['product_id' => $data->item_id, 'language' => 1]);
                    $product_data = $this->SearchItemDetail($request)->getData()->data; // Call the function for Product detail with price
                    $data->product_data = $product_data;
                } else {

                    $serviceData = CRMServiceItem::where(['id' => $data->item_id])->first();
                    $data->product_data = $serviceData;
                }
                return $data;
            });
        }

        $app_invo_item = InvoicesItem::where("invoice_id", $app_invoice->id)->first();

        $customer = Customer::where('status', 1)->get();

        foreach ($customer as $Customer) {
            if (!empty($Customer)) {
                $Customer->setRelation('crm_customer_address', $Customer->crm_customer_address()->where(['status' => 1, 'address_type' => 2])->get());
            }

            $address_list = $Customer->crm_customer_address->map(function ($data) {


                if (!empty($data->countries_id)) {
                    $data->country_name = Country::where('countries_id', $data->countries_id)->first()->countries_name;
                } else {
                    $data->country_name  = '';
                }


                return $data;
            });
        }

        $defaultCurrency = ApiHelper::getKeySetVal('default_currency');
        $currency = explode(',', ApiHelper::getKeySetVal('other_supported_currency'));

        $crmTaxGroup = SettingTaxGroup::with('tax_info')->where('status', 1)->get();

        $taxTypeIds = [];

        if (!empty($crmTaxGroup)) {
            foreach ($crmTaxGroup as $taxGroup) {
                if (!empty($taxGroup->tax_info)) {
                    foreach ($taxGroup->tax_info as $taxInfo) {
                        $tax_type = SettingTaxType::where('id', $taxInfo->tax_type_id)->first();
                        $taxInfo->tax_name = $tax_type->tax_name;

                        if (!in_array($taxInfo->tax_type_id, $taxTypeIds)) {
                            $taxTypeIds[] = $taxInfo->tax_type_id;
                        }
                    }
                }
            }
        }

        $invoice_data = [];

        $invoice_data['invoice_logo'] = ApiHelper::getKeySetVal('invoice_logo');
        $invoice_data['invoice_note'] = ApiHelper::getKeySetVal('invoice_note');
        $invoice_data['invoice_prefix'] = ApiHelper::getKeySetVal('invoice_prefix');

        $invoice_data['invoice_biller_address'] = !empty(ApiHelper::getKeySetVal('invoice_biller_address')) ? ApiHelper::getKeySetVal('invoice_biller_address') : ApiHelper::getKeyVal('contact_address')
            . ' ,' . ApiHelper::getKeyVal('contact_city') . ' ,' . ApiHelper::getKeyVal('contact_state') . ' ,' . ApiHelper::getKeyVal('contact_country') . ' ,' . ApiHelper::getKeyVal('contact_zipcode');
        $invoice_data['business_email'] = ApiHelper::getKeySetVal('business_email');
        $invoice_data['contact_phone'] = ApiHelper::getKeyVal('contact_phone');
        $invoice_data['company_name'] = !empty(ApiHelper::getKeySetVal('business_name')) ? ApiHelper::getKeySetVal('business_name') : ApiHelper::getKeyVal('company_name');

        $customer_addrs = CustomerAddress::where('address_id', $app_invoice->billing_address_id)->first();

        if (!empty($customer_addrs)) {

            if (!empty($customer_addrs->countries_id)) {
                $customer_addrs['country_name'] = Country::where('countries_id', $customer_addrs->countries_id)->first()->countries_name;
            } else {
                $customer_addrs['country_name']  = '';
            }
        }

        $invoice_data['customer_address'] = $customer_addrs;

        $paymentterms = SettingPaymentTerms::all();


        $res = [
            'app_invoice' => $app_invoice,
            'app_invo_item' => $app_invo_item,
            'customer' => $customer,
            'currency' => $currency,
            'TaxGroup' => $crmTaxGroup,
            'taxTypeIds' => $taxTypeIds,
            'defaultCurrency' => $defaultCurrency,
            'paymentterms' => $paymentterms,
            'invoice_data' => $invoice_data,
            'website_url' => ApiHelper::getKeyVal('website_url'),
            'invoice_type' => $invoice_type,
        ];

        return ApiHelper::JSON_RESPONSE(true, $res, '');
    }

    public function PaymentTerm(Request $request)
    {

        $payment_term_id = $request->payment_term_id;
        
        $ad_amount = $bal_amount = 0;
        if(isset($payment_term_id)){
            $term_details = SettingPaymentTerms::where('terms_id', $payment_term_id)->first();
            
            if(!empty($term_details)){
    
                $ad_amount = ($request->final_cost * $term_details->advance_payment) / 100;
                $bal_amount = ($request->final_cost * $term_details->balance_payment) / 100;
            }
        }


        $res = [
            'ad_amount' => $ad_amount,
            'bal_amount' => $bal_amount,
        ];

        return ApiHelper::JSON_RESPONSE(true, $res, '');
    }
}
