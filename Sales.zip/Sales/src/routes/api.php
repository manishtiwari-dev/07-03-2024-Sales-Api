<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

use Modules\Sales\Http\Controllers\SalesCustomerController;
use Modules\Sales\Http\Controllers\SalesQuotationController;
use Modules\Sales\Http\Controllers\WebEnquiryController;
use Modules\Sales\Http\Controllers\InvoiceController;
use Modules\Sales\Http\Controllers\OrderController;


/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/


Route::group(['middleware' => ['ApiTokenCheck'], 'prefix' => "api/"], function () {



    //CRM crm_customer API
    Route::group(['prefix' => 'crm_customer'], function () {
        Route::post('/', [SalesCustomerController::class, 'index']);
        Route::post('/store', [SalesCustomerController::class, 'store']);
        Route::post('/edit', [SalesCustomerController::class, 'edit']);
        Route::post('/update', [SalesCustomerController::class, 'update']);
        Route::post('/view', [SalesCustomerController::class, 'view']);
        Route::post('/create', [SalesCustomerController::class, 'create']);
        Route::post('/isdefaultupdate', [SalesCustomerController::class, 'isdefaultupdate']);
        Route::post('/changeStatus', [SalesCustomerController::class, 'changeStatus']);
        Route::post('/changeGuest', [SalesCustomerController::class, 'changeGuest']);
        Route::post('/get-customer-details', [SalesCustomerController::class, 'customerDetails']);
    });
    //end CRM crm_customer API

    //CRM crm_quotation API
    Route::group(['prefix' => 'crm_quotation'], function () {
        Route::post('/', [SalesQuotationController::class, 'index']);
        Route::post('/store', [SalesQuotationController::class, 'store']);
        Route::post('/edit', [SalesQuotationController::class, 'edit']);
        Route::post('/update', [SalesQuotationController::class, 'update']);
        Route::post('/create', [SalesQuotationController::class, 'create']);
        Route::post('/customer/alldata', [SalesQuotationController::class, 'customeralldata']);
        Route::post('/contactsdata', [SalesQuotationController::class, 'ContactsInformation']);
        Route::post('/changeStatus', [SalesQuotationController::class, 'changeStatus']);
        Route::post('/SearchSuggestion', [SalesQuotationController::class, 'SearchSuggestion']);
        Route::post('/quotationdetailspdf', [SalesQuotationController::class, 'quotationdetailspdf']);
        Route::post('/send-reminder', [SalesQuotationController::class, 'sendReminder']);
        Route::post('search-item-detail', [SalesQuotationController::class, 'SearchItemDetail'])->name('SearchItemDetail');
        Route::post('/invoice-search-services', [SalesQuotationController::class, 'SearchServices']);
        Route::post('services-search-details', [SalesQuotationController::class, 'SearchServiceDetail'])->name('services-search-details');


        Route::post('service-data', [SalesQuotationController::class, 'serviceData'])->name('service-data');
        Route::post('service-destroy', [SalesQuotationController::class, 'serviceDestroy'])->name('service-destroy');
        Route::post('service-update', [SalesQuotationController::class, 'ServiceUpdate'])->name('service-update');
    });
    //end CRM crm_quotation API



    Route::group(
        ['prefix' => 'orders'],
        function () {
            Route::post('/', [OrderController::class, 'index']);
            Route::post('/detail', [OrderController::class, 'orderDetails']);
            Route::post('/changeStatus', [OrderController::class, 'changeStatus']);
            Route::post('/order-details-pdf', [OrderController::class, 'orderdetailspdf']);
            // Route::post('/order-filter', [OrderController::class,'OrderFilter']);
            Route::post('/order-updates', [OrderController::class, 'UpdateOrderStatus']);
        }
    );


    //Web Enquiry prefix

    Route::group(['prefix' => 'enquiry'], function () {
        Route::post('/', [WebEnquiryController::class, 'index']);
        Route::post('/store', [WebEnquiryController::class, 'store']);
        Route::post('/edit', [WebEnquiryController::class, 'edit']);
        Route::post('/update', [WebEnquiryController::class, 'update']);
        Route::post('/destroy', [WebEnquiryController::class, 'destroy']);
        Route::post('/changeStatus', [WebEnquiryController::class, 'changeStatus']);
        Route::post('/enquiry_details', [WebEnquiryController::class, 'enquiry_details']);
    });

    //end enquiry









    //sales invoices
    Route::group(['prefix' => 'invoices'], function () {
        Route::post('/', [InvoiceController::class, 'index']);
        Route::post('/store', [InvoiceController::class, 'store']);
        Route::post('/create', [InvoiceController::class, 'create']);
        Route::post('/edit', [InvoiceController::class, 'edit']);
        Route::post('/update', [InvoiceController::class, 'update']);
        Route::post('/destroy', [InvoiceController::class, 'destroy']);
        Route::post('/invoicesdetailspdf', [InvoiceController::class, 'InvoiceDetailsPDF']);
        Route::post('/changeStatus', [InvoiceController::class, 'changeStatus']);
        Route::post('/changeDate', [InvoiceController::class, 'changeDate']);
        Route::post('/service-add', [InvoiceController::class, 'serviceAdd']);
        Route::post('/download-invoice', [InvoiceController::class, 'invoiceDownload']);
        Route::post('/dublicate', [InvoiceController::class, 'dublicate']);
        Route::post('/payment_term_search', [InvoiceController::class, 'PaymentTerm']);
    });
});
